package com.koreait.springMVCBoard_DBCP;

import org.springframework.jdbc.core.JdbcTemplate;

public class Constant {

	public static JdbcTemplate jdbcTemplate;
	
}
