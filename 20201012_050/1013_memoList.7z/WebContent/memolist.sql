SELECT * FROM memolist ORDER BY idx DESC;
