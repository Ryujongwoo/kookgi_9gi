package com.koreait.dao;

public interface MybatisDAO {

	
	
}
